package integracao.bancodedados.BancoDeDados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoDeDadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoDeDadosApplication.class, args);
	}

}
