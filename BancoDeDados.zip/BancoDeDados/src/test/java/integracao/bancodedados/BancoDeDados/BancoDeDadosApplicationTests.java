package integracao.bancodedados.BancoDeDados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoDeDadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
